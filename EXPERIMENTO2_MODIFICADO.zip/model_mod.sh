#! /bin/sh
# File: model1.sh

# Set messages on
set -x

# Experiment Number
num=2

# Name output binary model file
modfile=model${num}.dat

# Name output encapsulated Postscript image file
psfile=model${num}.eps

# Remove previous .eps file
rm -f $psfile

trimodel xmin=0 xmax=6 zmin=0 zmax=2 \
1 xedge=0,6 \
  zedge=0,0 \
  sedge=0,0 \
2 xedge=0,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3,3.2,3.4,3.6,3.8,4,4.2,4.4,4.6,6 \
  zedge=1.00,1.00,1.00,0.92,0.83,0.76,0.69,0.64,0.61,0.60,0.61,0.64,0.69,0.75,0.83,0.92,1.00,1.00,1.00 \
  sedge=0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 \
3 xedge=0,6 \
  zedge=2,2 \
  sedge=0,0 \
 kedge=1,2,3 \
 sfill=0.1,0.1,0,0,0.44,0,0 > $modfile
##       x,z

# Create a Postscipt file of the model
#   Set gtri=1.0 to see sloth triangle edges
spsplot < $modfile > $psfile \
        gedge=0.5 gtri=2.0 gmin=0 gmax=1 \
        title="Earth Model - 5 layers  [M${num}]" \
        labelz="Depth (km)" labelx="Distance (km)" \
        dxnum=1.0 dznum=0.5 wbox=6 hbox=2

# Exit politely from shell
exit

