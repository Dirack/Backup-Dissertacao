#! /bin/sh


#num=1
rm -r tracos_separados
rm -r tracos_separados_dat
mkdir tracos_separados
mkdir tracos_separados_dat

#aplicar ganho no traço
#sugain < rox.su  tpow=2 > rox_g.su

for i in {2..60}

do
num=${i}

suwind <cdp_160.su key=tracf min=${num} max=${num} > traco${num}.su


#surange < traco${num}.su

#suxwigb < traco${num}.su title="traco -  $num levantamento: Lousiana" key=offset label1="Tempo (s)" label2="Traco" perc=99 &

suascii < traco${num}.su bare=4 index=0 > traco_${num}.dat

mv traco${num}.su tracos_separados
mv traco_${num}.dat tracos_separados_dat

done




#exit
