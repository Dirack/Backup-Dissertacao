#!/bin/bash

rm teste.txt
ls cdp -1 | sed 's/^cdp_//' >> teste.txt
clear

rm -r figuras
mkdir figuras

while read linha
do

i=$linha

roma='s/^substitua/ccc='${i}'/'

sed $roma <monta_curva.sce> cdp/cdp_$i/monta_curva.sce
#cp monta_curva.sce cdp/cdp_139

#execute monta curva
rm cdp/cdp_$i/parametros.txt
ls cdp/cdp_$i/traco_* | wc -l >> cdp/cdp_$i/parametros.txt
echo "$i" >> cdp/cdp_$i/parametros.txt

scilab-adv-cli -f cdp/cdp_$i/monta_curva.sce -nb

done < teste.txt





#exit
