#! /bin/sh
# File: model1.sh

# Set messages on
set -x

# Experiment Number
num=2

# Name output binary model file
modfile=model${num}.dat

# Name output encapsulated Postscript image file
psfile=model${num}.eps

# Remove previous .eps file
rm -f $psfile

trimodel xmin=0 xmax=6 zmin=0 zmax=2 \
1 xedge=0,6 \
  zedge=0,0 \
  sedge=0,0 \
2 xedge=0,0.50,2,2.25,2.50,2.75,3,3.25,3.50,3.75,4,6 \
  zedge=0.83,0.83,0.83,0.74,0.66,0.62,0.60,0.61,0.66,0.74,0.83,0.83 \
  sedge=0,0,0,0,0,0,0,0,0,0,0,0 \
3 xedge=0,2,4,6 \
  zedge=1.30,1.30,1.30,1.30 \
  sedge=0,0,0,0 \
4 xedge=0,2,4,6 \
  zedge=1.50,1.50,1.50,1.50 \
  sedge=0,0,0,0 \
5 xedge=0,2,4,6 \
  zedge=1.60,1.60,1.60,1.60 \
  sedge=0,0,0,0 \
6 xedge=0,6 \
  zedge=2,2 \
  sedge=0,0 \
 kedge=1,2,3,4,5,6 \
 sfill=0.1,0.1,0,0,0.44,0,0 \
 sfill=0.1,0.9,0,0,0.40,0,0 \
 sfill=0.1,1.4,0,0,0.35,0,0 \
 sfill=0.1,1.6,0,0,0.30,0,0 \
 sfill=0.1,1.7,0,0,0.25,0,0 > $modfile
##       x,z

# Create a Postscipt file of the model
#   Set gtri=1.0 to see sloth triangle edges
spsplot < $modfile > $psfile \
        gedge=0.5 gtri=2.0 gmin=0 gmax=1 \
        title="Earth Model - 5 layers  [M${num}]" \
        labelz="Depth (km)" labelx="Distance (km)" \
        dxnum=1.0 dznum=0.5 wbox=6 hbox=2

# Exit politely from shell
exit

