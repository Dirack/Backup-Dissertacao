#! /bin/sh
# sort2cmp.sh

# Compute CMP header
suchw < seis2.su key1=cdp key2=gx key3=sx a=1525 b=1 c=1 d=50 susort > cmp1.su cdp offset

# Exit politely from shell
exit 0

