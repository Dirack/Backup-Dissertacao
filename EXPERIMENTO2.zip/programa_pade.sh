#!/bin/bash

#gerar modelo do refletor hiperbólico
#./model1.sh

#terminei
clear

#realizar aquisição
#./acq_mod.sh

#terminei
clear

#realizando sorting agrupando em CMP
#./03_sort2cmp.sh
#terminei
clear

#gerando arquivo com a geometria 
#./geometria
#terminei
clear

#separando os CMP's em arquivos ASCII
#scilab-adv-cli -f fold.sce -nb
#terminei
clear

#gere a curva de tempo de trânsito e aproximações para cada CMP
./mcurva.sh
#terminei
clear

#exit 

