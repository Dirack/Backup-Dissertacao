#!/bin/bash

rm -r cdp
mkdir cdp
#rm -r tracos_separados.dat
#mkdir tracos_separados.dat

echo $1 
echo $2 
echo $3

for i in $(seq $1 1 $2)

do

	suwind <cmp1.su key=cdp min=${i} max=${i} > cdp_${i}.su
	<cdp.su sugethw key=offset > offi.txt
	sed 's/offset=//;/^$/d' <offi.txt> off.txt
	rm offi.txt


	
	# separa os traços para cada cmp

        for j in $(seq 1 1 $3)

        do
                suwind <cdp_$i.su key=tracf min=${j} max=${j} | suascii bare=4 index=0 > traco_${j}.dat

               
        done
	
	mkdir cdp_$i
	mv traco_*.dat cdp_$i
	mv off.txt cdp_$i
	rm cdp_$i.su
	mv cdp_$i cdp

clear
done




#exit

