#! /bin/sh

# File: showcmp.sh: Window one CMP from file seis#.su
#                   where # represents the model number.
# Specify input model number and output CMP
# Input:  CMP file
# Outputs: CMP gather in .su format
#          wiggle image of the CMP gather
#          .eps file of the CMP gather
# Use:     showcmp.sh [model] [cmp]
# Example: showcmp.sh    4     20

# Set messages on
##set -x

# Display a CMP gather between 1 and 458
if [ $2 -le 458 ]; then
  if [ $2 -ge 1 ]; then

    suwind < cmp$1.su key=cdp min=$2 max=$2 > cmp$1$2.su

    suxwigb < cmp$1$2.su title="CMP # $2 [$1]" key=offset \
            label1=" Time (s)" label2="Offset (m)" \
            perc=99 &

    supswigp < cmp$1$2.su title="CMP # $2 [$1]" key=offset \
             label2="Time (s)" label2="Offset (m)" \
             x2beg=-1500 x2end=1500 perc=99 > cmp$1$2.eps

    exit

  fi
fi

echo usage: showcmp.sh [model number] [CMP between 1 and 458]

# Exit politely from shell
exit

